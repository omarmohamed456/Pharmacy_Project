import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Drug myDrug = new Drug();

    }
}
//1.drug class with atrtributes constructor set and get
//2. input method and capacity question
//3.pharmacy class?
//4.order class?
//5.menu and switch case
//6.methods
//7.test
//8.gui


//2. add a category for prescription/cosmetics and other after search by id in place order the program will check then apply  specified task

//3. pharmacy capacity when program runs

//4. GUI  will be a small window with blue color/photo with five methods resampling the methods asked for

//5. probably the input method will be the mouse but if not there will be a small input box

//6. a file may be needed as a database? (حزق)


//1. drug class  drug name, id, price, category, available quantity (can add only when there is place )
class Drug {
    String drug_name;
    int drug_id;
    float drug_price;
    String drug_category;
    int quantity; //default should be others?

    //constructor
    Drug() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter drug name: ");
        this.drug_name = sc.nextLine();

        System.out.print("Enter drug ID: ");
        this.drug_id = sc.nextInt();

        System.out.print("Enter drug price: ");
        this.drug_price = sc.nextFloat();

        sc.nextLine(); // Clear the buffer (important after nextFloat or nextInt)

        System.out.print("Enter drug category: ");
        this.drug_category = sc.nextLine();

        System.out.print("Enter quantity: ");
        this.quantity = sc.nextInt();
    }

    //getters
    public String getDrug_name() {
        return drug_name;
    }

    public int getDrug_id() {
        return drug_id;
    }

    public float getDrug_price() {
        return drug_price;
    }

    public String getDrug_category() {
        return drug_category;
    }

    public int getQuantity() {
        return quantity;
    }

    //setters
    public void setDrug_name(String drug_name) {
        this.drug_name = drug_name;
    }

    public void setDrug_id(int drug_id) {
        this.drug_id = drug_id;
    }

    public void setDrug_price(float drug_price) {
        this.drug_price = drug_price;
    }

    public void setDrug_category(String drug_category) {
        this.drug_category = drug_category;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
};