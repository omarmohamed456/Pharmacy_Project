import javax.swing.*;

//linked list
//node
class Node {
    Drug data;
    Node next; // Pointer to the next node

    public Node(Drug data) {
        this.data = data;
        this.next = null;
    }
}

//linked list class
class Linked_list {  //to store drugs

    Node head;

    // Add method
    public void add(Drug data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;  // If the list is empty, set head to the new node
        } else {
            Node current = head;  // Start from the head
            while (current.next != null) {
                current = current.next;  // Move to the next node
            }
            current.next = newNode;  // Link the last node to the new node
        }
    }

    //remove method
    public void remove(int id) {
        if (head == null) {
            JOptionPane.showMessageDialog(null, "There are no drugs");
            return;
        }

        // Special case: if head node needs to be deleted
        if (head.data.drug_id == id) {
            head = head.next;
            JOptionPane.showMessageDialog(null, "Drug removed");
            return;
        }

        Node previous = head;
        Node current = head.next;

        while (current != null) {
            if (current.data.drug_id == id) {
                previous.next = current.next;
                JOptionPane.showMessageDialog(null, "Drug removed");
                return;
            }
            previous = current;
            current = current.next;
        }
    }

    public Drug searchByName(String name) { // search for place order not used with remove

        Node current = head; //determine start

        while (current != null) {
            if (current.data.getDrug_name().equals(name)) { //check if exist
                if (current.data.quantity != 0) { //check if available

//                    current.data.quantity -=1;//drug found and quantity will be - 1   //this used in order and remove for the remove it deletes all the drug data so it won't harm

                    return current.data;
                } else {
                    return new Drug("fake", 500, 0.0f, "fake","none" ,0); // creates a fake "quantity zero" Drug to pass the null error (without it the code returns null which causes an error when tryinh to check the quantity)
                }
            }
            current = current.next; //traverse (this must be INSIDE while loop)
        }

        return null; //returns null because of the return type of the function the null is not used
    }

    public Drug searchById(int id) { //used with place order

        Node current = head; //determine start

        while (current != null) {
            if (current.data.getDrug_id() == id) { //check if exist

                if (current.data.quantity != 0) { //check if available

                    return current.data;

                } else {
                    return new Drug("fake", 500, 0.0f, "fake","none" ,0); // creates a fake "quantity zero" Drug to pass the null error (without it the code returns null which causes an error when tryinh to check the quantity)
                }
            }
            current = current.next; //traverse (this must be INSIDE while loop)
        }

        return null; //returns null because of the return type of the function null is used in remove
    }
}