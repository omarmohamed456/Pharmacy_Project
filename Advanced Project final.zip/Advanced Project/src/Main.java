import javax.swing.*; //both used for GUI Jlabel jbutton
import java.awt.*; //both used for GUI  Image grid
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

public class Main {
    static Pharmacy pharmacy = new Pharmacy(0);

    public static void main(String[] args) {

        //pharmacy main window and methods

        //GUI

        // Create a new JFrame
        JFrame mainwindow = new JFrame("BTATS PHARMACY"); //window creation
        mainwindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //use x to close
        mainwindow.setSize(600, 800); // Set size directly
        mainwindow.setLocationRelativeTo(null); // Center window in screen

        // Load and scale the background image
        ImageIcon Background_Image = new ImageIcon(Main.class.getResource("/SKY_Image.jpg")); //create image label and import it
        Image scaledImage = Background_Image.getImage().getScaledInstance(600, 800, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel Background_Label = new JLabel(scaledIcon); //container for the background
        Background_Label.setLayout(null); // Use absolute positioning for precise placement

        //Pharmacy Icon - top left corner
        ImageIcon Pharmacy_Icon = new ImageIcon(Main.class.getResource("/pharmacyicon.png"));
        Image scaledIconImg = Pharmacy_Icon.getImage().getScaledInstance(65, 65, Image.SCALE_SMOOTH);
        JLabel Pharmacy_Icon_label = new JLabel(new ImageIcon(scaledIconImg));
        Pharmacy_Icon_label.setBounds(10, 10, 65, 65); // top-left corner (0 padding)

        //Pharmacy Icon - bottom
        ImageIcon Pharmacy_Icon2 = new ImageIcon(Main.class.getResource("/pharmacyicon.png"));
        Image scaledIconImg2 = Pharmacy_Icon2.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH); // scaled smaller
        JLabel Pharmacy_Icon_label2 = new JLabel(new ImageIcon(scaledIconImg2));
        Pharmacy_Icon_label2.setHorizontalAlignment(SwingConstants.CENTER); // center inside container

        // Bottom container for the bottom icon
        JPanel bottomIconContainer = new JPanel(new BorderLayout());
        bottomIconContainer.setBounds(95, 430, 400, 400); // x, y, width, height  //if x increased it goes right //if y increased it goes down
        bottomIconContainer.setOpaque(false); // make it transparent
        bottomIconContainer.add(Pharmacy_Icon_label2, BorderLayout.CENTER); 

        // Welcome label - centered with top padding
        JLabel welcomeLabel = new JLabel("Welcome to BTATS PHARMACY :D", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setOpaque(false);
        welcomeLabel.setBounds(0, 30, 600, 40); // 30px from top, centered horizontally

        //Buttons
        JPanel Buttons_Continer = new JPanel();
        Buttons_Continer.setBounds(95, 105, 400, 400); // x, y, width, height
        Buttons_Continer.setOpaque(false);
        Buttons_Continer.setLayout(new BoxLayout(Buttons_Continer, BoxLayout.Y_AXIS)); // Vertical layout


        //Buttons and actions
        // dd_Drug Button
        Buttons_Continer.add(Create_Button("Add a drug" , "add.png",() -> Add_Drug_GUI()));
        Buttons_Continer.add(Box.createVerticalStrut(30));

        // Remove_drug Button
        Buttons_Continer.add(Create_Button("Remove a drug", "remove.png",() -> Remove_drug_GUI()));
        Buttons_Continer.add(Box.createVerticalStrut(30));

        // Display_All Button
        Buttons_Continer.add(Create_Button("Display all available drugs","display.png",() -> Display_All_GUI(pharmacy.list)));
        Buttons_Continer.add(Box.createVerticalStrut(30));

        // place_an_order Button
        Buttons_Continer.add(Create_Button("Place an order","order.png",() -> Place_an_order()));
        Buttons_Continer.add(Box.createVerticalStrut(30));

        // Get_total Button
        Buttons_Continer.add(Create_Button("Total sales of the day","total.png",() -> Get_total_GUI()));
        Buttons_Continer.add(Box.createVerticalStrut(30));

        // Exit Button
        Buttons_Continer.add(Create_Button("Exit","exit.png",() -> System.exit(0)));


        //button method outside main to avoid error

        // Add components
        Background_Label.add(Pharmacy_Icon_label);
        Background_Label.add(bottomIconContainer);
        Background_Label.add(welcomeLabel);
        Background_Label.add(Buttons_Continer);

        mainwindow.setContentPane(Background_Label); // replace the entire background
        mainwindow.setVisible(true);

        clearTotalFile(); // Clear the file when program starts


    }


    //method to create 6 buttons (menu) with name and action as parameters
    private static JButton Create_Button(String text, String iconPath,Runnable action) {
        JButton button = new JButton(text); //button creation

        // Custom painting for rounded corners
        button = new JButton(text) {

            @Override //JComponent
            protected void paintComponent(Graphics g) {

                Graphics2D g2 = (Graphics2D) g.create(); //for advance styling

                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); //modern and smooth look

                // Background color
                if (getModel().isArmed()) { //is armed (when clicked)
                    g2.setColor(new Color(41, 128, 185)); //before click
                } else {
                    g2.setColor(new Color(52, 152, 219)); //after click
                }

                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30); // Rounded corners

                super.paintComponent(g); // calls the original button painting //ensures unedited parts will appear

                g2.dispose(); //Cleans up the Graphics2D object we created to prevent memory leaks. //file close

            }

            @Override //JComponent
            protected void paintBorder(Graphics g) { //removes old boarders
                // no border
            }
        };

        // icon
        if (iconPath != null && !iconPath.isEmpty()) {
            ImageIcon icon = new ImageIcon(Main.class.getResource(iconPath));
            icon = new ImageIcon(icon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
            button.setIcon(icon);
            button.setIconTextGap(10);
        }

        //style
        button.setForeground(Color.WHITE); //text color
        button.setFont(new Font("Segoe UI", Font.BOLD, 16)); //font
        button.setCursor(new Cursor(Cursor.HAND_CURSOR)); //change cursor
        button.setFocusPainted(false); //removes tab box
        button.setContentAreaFilled(false); //Makes the button’s background transparent //so only custom style is shown
        button.setOpaque(false); //transparency
        button.setMargin(new Insets(10, 20, 10, 20)); //inside margin
        button.setAlignmentX(Component.CENTER_ALIGNMENT); //buttons centered in the container

        // Action
        button.addActionListener(e -> action.run());

        return button;
    }

    //methods GUI
    private static void Add_Drug_GUI() { //this function takes the input and passes it down to the add drug which Checks the capacity then creates the drug and adds it to the list by calling add // Create the "Add Drug" window

        JFrame addDrugFrame = new JFrame("Add Drug"); //obj and title
        addDrugFrame.setSize(520, 300);
        addDrugFrame.setLocationRelativeTo(null); //null means centered in the  screen
        addDrugFrame.setLayout(new GridLayout(6, 2)); // 6 rows, 2 columns for inputs name -> inbut + submit button

        // Drug name input
        JLabel drugNameLabel = new JLabel("Drug Name: ");
        JTextField drugNameField = new JTextField(20);

        // Drug ID input
        JLabel drugIdLabel = new JLabel("Drug ID: ");
        JTextField drugIdField = new JTextField(20);

        // Price input
        JLabel priceLabel = new JLabel("Price: ");
        JTextField priceField = new JTextField(20);

        // Category input
        JLabel categoryLabel = new JLabel("Category: (prescription - cosmetics - other)");
        JTextField categoryField = new JTextField(20);

        // Quantity input
        JLabel quantityLabel = new JLabel("Quantity: ");
        JTextField quantityField = new JTextField(20);

        // Submit button
        JButton submitBtn = new JButton("Submit");

        submitBtn.addActionListener(e -> {
            try {
                // Get and validate inputs
                String drugName = drugNameField.getText().trim(); //.trim() Remove any spaces at the start and end of the input.
                if (drugName.isEmpty()) {
                    JOptionPane.showMessageDialog(addDrugFrame, "Drug name is required.");
                    return;
                }

                int drugId;
                try {
                    drugId = Integer.parseInt(drugIdField.getText().trim());
                    if (drugId <= 0) {
                        JOptionPane.showMessageDialog(addDrugFrame, "Invalid ID. Please enter a positive integer.");
                        return;
                    }
                } catch (NumberFormatException ex) { //try catch
                    JOptionPane.showMessageDialog(addDrugFrame, "Invalid ID. Please enter a valid integer.");
                    return;
                }

                float price;
                try {
                    price = Float.parseFloat(priceField.getText().trim());
                    if (price <= 0) {
                        JOptionPane.showMessageDialog(addDrugFrame, "Invalid price. Must be greater than 0.");
                        return;
                    }
                } catch (NumberFormatException ex) { //try catch
                    JOptionPane.showMessageDialog(addDrugFrame, "Invalid price. Please enter a valid decimal number.");
                    return;
                }
                int quantity;
                try {
                    quantity = Integer.parseInt(quantityField.getText().trim());
                    if (quantity <= 0) {
                        JOptionPane.showMessageDialog(addDrugFrame, "Invalid quantity. Must be greater than 0.");
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(addDrugFrame, "Invalid quantity. Please enter a valid integer.");
                    return;
                }

                if (pharmacy.drug_capacity + quantity > pharmacy.getCapacity()) {
                    JOptionPane.showMessageDialog(addDrugFrame, "Cannot add drug. Quantity exceeds pharmacy capacity.");
                    return;
                }

                String category = categoryField.getText().trim().toLowerCase();
                if (!(category.equals("cosmetics") || category.equals("prescription") || category.equals("other"))) {
                    JOptionPane.showMessageDialog(addDrugFrame, "Invalid category. Choose between 'cosmetics', 'prescription', or 'other'.");
                    return;
                }

                if (category.equals("prescription")) {
                    // Ask for prescription
                    JFrame prescriptionFrame = new JFrame("Prescription");
                    prescriptionFrame.setSize(300, 100);
                    prescriptionFrame.setLocationRelativeTo(null);
                    prescriptionFrame.setLayout(new GridLayout(2, 2));

                    JLabel prescriptionLabel = new JLabel("Prescription: ");

                    JTextField prescriptionField = new JTextField(20);

                    JButton submitPrescriptionBtn = new JButton("Submit");

                    submitPrescriptionBtn.addActionListener(e2 -> {

                        String prescription = prescriptionField.getText().trim();

                        if (prescription.isEmpty()) {

                            JOptionPane.showMessageDialog(prescriptionFrame, "Prescription is required.");

                            return;
                        }

                        pharmacy.Add_drug(drugName, drugId, price, category, prescription, quantity);


                        prescriptionFrame.dispose();
                        addDrugFrame.dispose();
                    });

                    prescriptionFrame.add(prescriptionLabel);
                    prescriptionFrame.add(prescriptionField);
                    prescriptionFrame.add(new JLabel()); // empty label for layout
                    prescriptionFrame.add(submitPrescriptionBtn);

                    prescriptionFrame.setVisible(true);

                } else {

                    pharmacy.Add_drug(drugName, drugId, price, category, "none",quantity);

                    addDrugFrame.dispose();
                }



            } catch (Exception ex) {
                JOptionPane.showMessageDialog(addDrugFrame, "Something went wrong. Please try again.");
            }
        });

        // Add the components to the window //note the is no  Background_Label.add(addDrugFrame); because this is a separate window
        //name
        addDrugFrame.add(drugNameLabel);
        addDrugFrame.add(drugNameField);
        //ID
        addDrugFrame.add(drugIdLabel);
        addDrugFrame.add(drugIdField);
        //price
        addDrugFrame.add(priceLabel);
        addDrugFrame.add(priceField);
        //category
        addDrugFrame.add(categoryLabel);
        addDrugFrame.add(categoryField);
        //quantity
        addDrugFrame.add(quantityLabel);
        addDrugFrame.add(quantityField);
        //submit
        addDrugFrame.add(submitBtn);
        //visible
        addDrugFrame.setVisible(true);
    }

    private static void Remove_drug_GUI(){
        //create window
        JFrame RemoveDrugFrame = new JFrame("Remove Drug"); //obj and title
        RemoveDrugFrame .setSize(300, 70);
        RemoveDrugFrame .setLocationRelativeTo(null); //null means centered in the  screen
        RemoveDrugFrame .setLayout(new GridLayout(1, 2)); //input name -> input + submit button

        //create Label
        JLabel drugIDLabel = new JLabel("Drug ID: ");
        //create input  field
        JTextField drugIDField = new JTextField(20);
        // Submit button
        JButton submit_Remove_button = new JButton("Submit");
        submit_Remove_button.addActionListener(e -> {

            int drugID;

            try {
                drugID = Integer.parseInt(drugIDField.getText().trim());
                if (drugID <= 0) {
                    JOptionPane.showMessageDialog(RemoveDrugFrame, "Invalid drug ID. Please enter a valid integer. >0");
                    return;
                }
            } catch (NumberFormatException ex) { //try catch
                JOptionPane.showMessageDialog(RemoveDrugFrame, "Invalid ID. Please enter a valid integer.");
                return;
            }

            pharmacy.Remove_drug(drugID); // real function
//            drugID.get(quantity);
            RemoveDrugFrame.dispose(); // close window
        });

        RemoveDrugFrame.add(drugIDLabel);
        RemoveDrugFrame.add(drugIDField);
        RemoveDrugFrame.add(submit_Remove_button);
        RemoveDrugFrame.setVisible(true);
    }

    //not asked for in PDF
    private static void Display_All_GUI(Linked_list list) {
        JFrame allDrugsFrame = new JFrame("All Drugs");
        allDrugsFrame.setSize(600, 600);
        allDrugsFrame.setLocationRelativeTo(null);
        allDrugsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS)); // vertical layout

        Node current = list.head; // start from head
        if (list.head != null) {

            while (current != null) {
                Drug drug = current.data; // get the drug from the node

                JPanel card = new JPanel();
                card.setLayout(new GridLayout(0, 1));
                card.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // card border
                card.setBackground(new Color(52, 152, 219));
                card.setPreferredSize(new Dimension(500, 150));
                card.setMaximumSize(new Dimension(500, 150));

                // Add drug details
                card.add(new JLabel("Name: " + drug.getDrug_name()));
                card.add(new JLabel("ID: " + drug.getDrug_id()));
                card.add(new JLabel("Price: " + drug.getDrug_price()));
                card.add(new JLabel("Category: " + drug.getDrug_category()));
                card.add(new JLabel("Prescription: " + drug.getPrescription()));
                card.add(new JLabel("Quantity: " + drug.getQuantity()));

                mainPanel.add(Box.createRigidArea(new Dimension(0, 10))); // margin between cards
                mainPanel.add(card);

                current = current.next; // move to next node
            }
        }  else{

            JPanel card = new JPanel();
            card.setLayout(new GridLayout(0, 1));
            card.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            card.setBackground(new Color(52, 152, 219));
            card.setPreferredSize(new Dimension(500, 150));
            card.setMaximumSize(new Dimension(500, 150));

            card.add(new JLabel("There are no drugs here."));

            mainPanel.add(Box.createRigidArea(new Dimension(0, 10))); // margin between cards
            mainPanel.add(card);
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        allDrugsFrame.add(scrollPane);
        allDrugsFrame.setVisible(true);
    }

    private static void Place_an_order(){
        String[] responses= {"Name", "ID"};

        int value = JOptionPane.showOptionDialog(

                null,
                "Do you want to search by name or ID?",
                "choose",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                responses,
                null
        );
        if (value == 0) {

            Place_an_order_by_Name_GUI();

        }
        else if(value == 1) {

            Place_an_order_by_ID_GUI();

        }

        else JOptionPane.showMessageDialog(null, "Operation Canceled", "Canceled", JOptionPane.ERROR_MESSAGE ); //not added or removed

    }

    private static void Place_an_order_by_Name_GUI() {
        //create window
        JFrame Place_an_orderFrame = new JFrame("Place an order"); //obj and title
        Place_an_orderFrame.setSize(300, 160);
        Place_an_orderFrame.setLocationRelativeTo(null); //null means centered in the  screen
        Place_an_orderFrame.setLayout(new GridLayout(3, 2)); //input name -> input + submit button

        //create Label
        JLabel drugIDLabel = new JLabel("Drug Name: ");
        //create input  field
        JTextField searchIDField = new JTextField(20);

        //create Label
        JLabel drugQuantityLabel = new JLabel("Quantity: ");
        //create input field
        JTextField drugQuantityField = new JTextField(20);

        // Submit button
        JButton submit_Place_an_order_button = new JButton("Submit");

        submit_Place_an_order_button.addActionListener(e -> {

            String search_name = searchIDField.getText().trim();

            int order_quantity;

            try {
                order_quantity = Integer.parseInt(drugQuantityField.getText().trim());

                if (order_quantity <= 0) {
                    JOptionPane.showMessageDialog(Place_an_orderFrame, "Invalid drug quantity. Please enter a valid integer. >0");
                    return;
                }

            } catch (NumberFormatException ex) { //try catch
                JOptionPane.showMessageDialog(Place_an_orderFrame, "Invalid quantity. Please enter a valid integer.");
                return;
            }

            pharmacy.Place_an_order_by_Name(search_name, order_quantity); // real function
            Place_an_orderFrame.dispose();
        });

        Place_an_orderFrame.add(drugIDLabel);
        Place_an_orderFrame.add(searchIDField);
        Place_an_orderFrame.add(drugQuantityLabel);
        Place_an_orderFrame.add(drugQuantityField);
        Place_an_orderFrame.add(submit_Place_an_order_button);
        Place_an_orderFrame.setVisible(true);
    }

    private static void Place_an_order_by_ID_GUI() {
        //create window
        JFrame Place_an_orderFrame = new JFrame("Place an order"); //obj and title
        Place_an_orderFrame.setSize(300, 160);
        Place_an_orderFrame.setLocationRelativeTo(null); //null means centered in the  screen
        Place_an_orderFrame.setLayout(new GridLayout(3, 2)); //input name -> input + submit button

        //create Label
        JLabel drugIDLabel = new JLabel("Drug ID: ");
        //create input  field
        JTextField searchIDField = new JTextField(20);

        //create Label
        JLabel drugQuantityLabel = new JLabel("Quantity: ");
        //create input field
        JTextField drugQuantityField = new JTextField(20);

        // Submit button
        JButton submit_Place_an_order_button = new JButton("Submit");

        submit_Place_an_order_button.addActionListener(e -> {

            int search_id;

            try {
                search_id = Integer.parseInt(searchIDField.getText().trim());

                if (search_id <= 0) {
                    JOptionPane.showMessageDialog(Place_an_orderFrame, "Invalid drug ID. Please enter a valid integer. >0");
                    return;
                }

            } catch (NumberFormatException ex) { //try catch
                JOptionPane.showMessageDialog(Place_an_orderFrame, "Invalid ID. Please enter a valid integer.");
                return;
            }

            int order_quantity;

            try {
                order_quantity = Integer.parseInt(drugQuantityField.getText().trim());

                if (order_quantity <= 0) {
                    JOptionPane.showMessageDialog(Place_an_orderFrame, "Invalid drug quantity. Please enter a valid integer. >0");
                    return;
                }

            } catch (NumberFormatException ex) { //try catch
                JOptionPane.showMessageDialog(Place_an_orderFrame, "Invalid quantity. Please enter a valid integer.");
                return;
            }

            pharmacy.Place_an_order_by_ID(search_id,order_quantity); // real function
            Place_an_orderFrame.dispose();
        });

        Place_an_orderFrame.add(drugIDLabel);
        Place_an_orderFrame.add(searchIDField);
        Place_an_orderFrame.add(drugQuantityLabel);
        Place_an_orderFrame.add(drugQuantityField);
        Place_an_orderFrame.add(submit_Place_an_order_button);
        Place_an_orderFrame.setVisible(true);
    }

    private static void clearTotalFile() { //used to clear the file so everytime the code runs the file is empty //it is called in the main methodf

        try (FileWriter writer = new FileWriter("totalData.txt", false)) {

            writer.write(""); // Write empty content to clear the file

        } catch (IOException e) {
            System.err.println("Failed to clear the file: " + e.getMessage());
        }
    }

    private static void Get_total_GUI(){

        float Total_GUI = pharmacy.Get_total();

        try { //write to file

            FileWriter writer = new FileWriter("totalData.txt", true);

            writer.write("Total sales of the day: " + Total_GUI + "\n");

            writer.close();

        } catch (IOException e) {

            JOptionPane.showMessageDialog(null, "An error occurred " + e.getMessage());

        }

        JOptionPane.showMessageDialog(null, "Total sales of the day: " + Total_GUI); //GUI
    }
}





