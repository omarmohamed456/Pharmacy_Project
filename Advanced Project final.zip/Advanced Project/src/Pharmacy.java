import javax.swing.*;
import java.util.ArrayList;

//pharmacy class //main action
class Pharmacy {

    int capacity; //max
    int drug_capacity; //keep counting the current

    //constructor that have the capacity GUI
    // to create pharmacy that have the methods and capacity
    Pharmacy(int drug_capacity) {

// Enter Pharmacy capacity

        boolean validInput = false;

        while (!validInput) {
            String input = JOptionPane.showInputDialog(
                    null,
                    "Enter Pharmacy capacity :D",
                    "Capacity Window",
                    JOptionPane.QUESTION_MESSAGE // sets the icon style.
            );

            if (input == null) { //if cancel is chose == null
                JOptionPane.showMessageDialog(null, "Programme Will Close", "Canceled", JOptionPane.ERROR_MESSAGE );
                System.exit(0);
            }

            try {
                this.capacity = Integer.parseInt(input); //convert to integer and  stop the loop if failed error and catch the loop continues
                validInput = true;

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number!");
            }
        }

        this.drug_capacity = drug_capacity;
    }

    //getter
    public int getCapacity() {
        return capacity;
    }

    public int getDrug_capacity() {
        return drug_capacity;
    }

    //linked list to store drugs
    Linked_list list = new Linked_list(); //for drugs
    ArrayList<Float> array = new ArrayList<>(); //for price (total)

    //Add drug
    //Add drug name, id, price, category, available quantity, the drug is added only if the pharmacy is still having place for adding a new drug.


    public void Add_drug(String drugName, int drugId, float price, String category, String prescription ,int quantity) { //this function works by passing the values inputted by the GUI function to the drug constructor that was edited specifically for that

        Drug check_drug_name = list.searchByName(drugName);
        Drug check_drug_id = list.searchById(drugId);

        if ((check_drug_name != null && drugName.equalsIgnoreCase(check_drug_name.getDrug_name())) || (check_drug_id != null && drugId == check_drug_id.getDrug_id())) {

            JOptionPane.showMessageDialog(null, "Drug with same name or ID already exist.");

        }
        else{

            if (category.equals("prescription")) {

                //drug OBJ create with prescription
                Drug drug = new Drug(drugName, drugId, price, category, prescription, quantity);
                list.add(drug); //add to linked list  //real function 2
                drug_capacity += quantity; //for capacity
                JOptionPane.showMessageDialog(null, "Drug added successfully!");

            } else {

                //drug OBJ create without prescription
                Drug drug = new Drug(drugName, drugId, price, category, quantity);
                list.add(drug); //add to linked list  //real function 2
                drug_capacity += quantity; //for capacity
                JOptionPane.showMessageDialog(null, "Drug added successfully!");

            }
        }
    }

    // Remove drug
    //When the user requests removing drug, allow the user to enter the id of the drug to remove it.
    public void Remove_drug(int drugID) { //note that remove deletes the drug and all related


        Drug current_drug = list.searchById(drugID); //get quantity

        if (current_drug == null) {

            JOptionPane.showMessageDialog(null, "Drug doesn't exist");

        } else {

            int quantity_remove = current_drug.getQuantity();
            drug_capacity -= quantity_remove; //for capacity //was there
            list.remove(drugID);

        }

    }

    //Place an order
    //When a user calls, asks for the availability of a certain drug the program search for the drug by its ID.
    // Get unit price,
    // print its price
    // and ask for the prescription in case that the drug needs so,
    // for the cosmetics, they are sold at price of 1.2 of its original price.
    public void Place_an_order_by_Name(String search_name, int order_quantity) {

        Drug current_drug = list.searchByName(search_name); //search check exist and available and print all details and return the found Drug

        if (current_drug == null) {

            JOptionPane.showMessageDialog(null, "Order could not be placed because the drug was not found."); //not added or removed

        } else if (current_drug.drug_name.equals("fake")) { // when fake drug is returned this will be printed because quantity is set to zero //after teh check in teh above method we know the quantity is zero so the fake drug is created depending on this logic

            JOptionPane.showMessageDialog(null, "Drug not available. (quantity is zero)"); //(quantity is zero)

        } else { // Cannot read field "drug_price" because "current_drug" is null

            if (order_quantity <= current_drug.quantity) {

                float Cosmetic_price = current_drug.drug_price * 1.2f; //Arraylist cannot be applied to float so it is float 1.2 by default is double so under java requierment we neeed 1.2f (converted to flaot)

                if (current_drug.drug_category.equalsIgnoreCase("cosmetics")) {

                    JOptionPane.showMessageDialog(null, "Total Price is: " + Cosmetic_price * order_quantity); //cosmetics
                    array.add(Cosmetic_price * order_quantity);
//                current_drug.drug_price -= 1; this is implemented in teh search method to handle zero quantity correctly
                    drug_capacity -= order_quantity; //new
                    current_drug.quantity -= order_quantity;

                }
                else if (current_drug.drug_category.equalsIgnoreCase("prescription")) {

                    JOptionPane.showMessageDialog(null, "Total Price is: " + current_drug.drug_price * order_quantity + "\n" + "Prescriptions are: " + current_drug.prescription); //other
                    array.add(current_drug.drug_price * order_quantity);
//                current_drug.drug_price -= 1; this is implemented in teh search method to handle zero quantity correctly
                    drug_capacity -= order_quantity;
                    current_drug.quantity -= order_quantity;

                }
                else { //other

                    JOptionPane.showMessageDialog(null, "Total Price is: " + current_drug.drug_price * order_quantity); //other
                    array.add(current_drug.drug_price * order_quantity);
//                current_drug.drug_price -= 1; this is implemented in teh search method to handle zero quantity correctly
                    drug_capacity -= order_quantity;
                    current_drug.quantity -= order_quantity;

                }
            }  else JOptionPane.showMessageDialog(null, "You can't place an order with quantity more than the drug's available quantity. Current quantity: " + current_drug.quantity); //other
        }
    }

    public void Place_an_order_by_ID(int search_id, int order_quantity) {

        Drug current_drug = list.searchById(search_id); //search check exist and available and print all details and return the found Drug

        if (current_drug == null) {

            JOptionPane.showMessageDialog(null, "Order could not be placed because the drug was not found."); //not added or removed

        } else if (current_drug.drug_name.equals("fake")) { // when fake drug is returned this will be printed because quantity is set to zero //after teh check in teh above method we know the quantity is zero so the fake drug is created depending on this logic

            JOptionPane.showMessageDialog(null, "Drug not available. (quantity is zero)"); //(quantity is zero)

        } else { // Cannot read field "drug_price" because "current_drug" is null

            if (order_quantity <= current_drug.quantity) {

                float Cosmetic_price = current_drug.drug_price * 1.2f; //Arraylist cannot be applied to float so it is float 1.2 by default is double so under java requierment we neeed 1.2f (converted to flaot)

                if (current_drug.drug_category.equalsIgnoreCase("cosmetics")) {

                    JOptionPane.showMessageDialog(null, "Total Price is: " + Cosmetic_price * order_quantity); //cosmetics
                    array.add(Cosmetic_price * order_quantity);
//                current_drug.drug_price -= 1; this is implemented in teh search method to handle zero quantity correctly
                    drug_capacity -= order_quantity; //new
                    current_drug.quantity -= order_quantity;

                }
                else if (current_drug.drug_category.equalsIgnoreCase("prescription")) {

                    JOptionPane.showMessageDialog(null, "Total Price is: " + current_drug.drug_price * order_quantity + "\n" + "Prescriptions are: " + current_drug.prescription); //other
                    array.add(current_drug.drug_price * order_quantity);
//                current_drug.drug_price -= 1; this is implemented in teh search method to handle zero quantity correctly
                    drug_capacity -= order_quantity;
                    current_drug.quantity -= order_quantity;

                }
                else { //other

                    JOptionPane.showMessageDialog(null, "Total Price is: " + current_drug.drug_price * order_quantity); //other
                    array.add(current_drug.drug_price * order_quantity);
//                current_drug.drug_price -= 1; this is implemented in teh search method to handle zero quantity correctly
                    drug_capacity -= order_quantity;
                    current_drug.quantity -= order_quantity;

                }
            }  else JOptionPane.showMessageDialog(null, "You can't place an order with quantity more than the drug's available quantity. Current quantity: " + current_drug.quantity); //other
        }
    }

    // Get the total sales for one day
    //For every order, the program stores the quantity and total price so that at the end of each day, it can calculate the total sale.
    public float Get_total() { //is this implementation accurate?
        float total = 0 ;

        for (int i = 0; i < array.size(); i++) { //the array is initiated in pharmacy
            total  += array.get(i);
        }
        return total;
    }
}
