//drug class
class Drug {
    String drug_name;
    int drug_id;
    float drug_price;
    String drug_category; //default should be others?
    String prescription;
    int quantity; //default should be others?

    //constructor for other and cosmetics
    public Drug(String drugName, int drugId, float price, String category,int quantity) {

        this(drugName, drugId, price, category, "none", quantity);

    }

    //constructor for prescription
    public Drug(String drugName, int drugId, float price, String category, String prescription ,int quantity) {
        this.drug_name = drugName;
        this.drug_id = drugId;
        this.drug_price = price;
        this.drug_category = category;
        this.prescription = prescription;
        this.quantity = quantity;
    }

    //getters
    public String getDrug_name() {
        return drug_name;
    }

    public int getDrug_id() {
        return drug_id;
    }

    public float getDrug_price() {
        return drug_price;
    }

    public String getDrug_category() {
        return drug_category;
    }

    public String getPrescription() {
        return prescription;
    }

    public int getQuantity() {
        return quantity;
    }
};